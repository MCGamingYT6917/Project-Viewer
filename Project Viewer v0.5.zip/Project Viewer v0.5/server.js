/*
 * server.js ‑ HTML Project Viewer backend
 * Compatible with Express 4.18.2
 */

const express     = require('express');
const fs          = require('fs');
const path        = require('path');
const bodyParser  = require('body-parser');

const app   = express();
const PORT  = 3000;

const htmlDir      = path.join(__dirname, 'html-files');
const projectsFile = path.join(__dirname, 'projects.json');

app.use(bodyParser.json());
app.use(express.static(__dirname));           // Serves index.html, manage.html, style.css…

/* ──────────────────────────────────────────────────────────────── */
/* Utility: recursive scan for folders that contain index.html     */
/* ──────────────────────────────────────────────────────────────── */
async function findProjects(dir) {
  const dirents  = await fs.promises.readdir(dir, { withFileTypes: true });
  const projects = [];

  for (const dirent of dirents) {
    const fullPath = path.join(dir, dirent.name);

    if (dirent.isDirectory()) {
      const indexPath = path.join(fullPath, 'index.html');
      if (fs.existsSync(indexPath)) {
        projects.push(path.relative(htmlDir, fullPath).replace(/\\/g, '/'));
      }
      const nested = await findProjects(fullPath);
      projects.push(...nested);
    }
  }
  return projects;
}

/* ──────────────────────────────────────────────────────────────── */
/* Utility: load / save projects.json                              */
/* ──────────────────────────────────────────────────────────────── */
function loadProjects() {
  if (!fs.existsSync(projectsFile)) return {};
  return JSON.parse(fs.readFileSync(projectsFile, 'utf8'));
}
function saveProjects(data) {
  fs.writeFileSync(projectsFile, JSON.stringify(data, null, 2));
}

/* ──────────────────────────────────────────────────────────────── */
/* ROUTES                                                          */
/* ──────────────────────────────────────────────────────────────── */

// List all detected projects
app.get('/list-projects', async (req, res) => {
  try {
    const projects = await findProjects(htmlDir);
    res.json(projects);
  } catch (err) {
    console.error('Error scanning projects:', err);
    res.status(500).send('Unable to scan project folders.');
  }
});

/*
 * Load any file inside html-files via URL:
 *   /load-html/<project>/<any/relative/path>
 *
 * Visibility rules:
 *   - If project has a "show" array and it's non‑empty → ONLY files in "show" are allowed
 *   - Otherwise, any file in "hide" is blocked
 *   - index.html is ALWAYS allowed so projects can load at least their entry point
 */
app.get('/load-html/:filepath(*)', (req, res) => {
  const reqPath  = req.params.filepath;                           // raw path from URL
  const safePath = path.normalize(reqPath).replace(/^(\.\.(\/|\\|$))+/, '');
  const filePath = path.join(htmlDir, safePath);

  // Security: must stay inside htmlDir
  if (!filePath.startsWith(htmlDir)) return res.status(403).send('Forbidden');

  // Extract project folder & relative file
  const parts         = safePath.split(/[\\/]/);
  const projectFolder = parts.shift();                            // first segment
  const relativeFile  = parts.join('/');                          // rest ('' for index.html in root)

  // Visibility enforcement
  const meta   = loadProjects()[projectFolder] || {};
  const always = ['index.html', ''];                              // index is always OK

  const isAllowedByShow =
    Array.isArray(meta.show) && meta.show.length > 0
      ? meta.show.includes(relativeFile) || always.includes(relativeFile)
      : true;                                                     // no show list → allow unless hidden

  const isHidden =
    Array.isArray(meta.hide) && meta.hide.includes(relativeFile) && !always.includes(relativeFile);

  if (!isAllowedByShow || isHidden) {
    return res.status(403).send('This file is hidden by project settings.');
  }

  // Serve the file
  fs.readFile(filePath, (err, data) => {
    if (err) return res.status(404).send('File not found');
    res.type(path.extname(filePath));
    res.send(data);
  });
});

// Get all project visibility configs
app.get('/api/projects', (req, res) => {
  res.json(loadProjects());
});

// Update a single project’s show/hide lists
app.post('/api/projects/:projectName', (req, res) => {
  const { projectName } = req.params;
  const { show = [], hide = [] } = req.body;

  const data           = loadProjects();
  data[projectName]    = { show, hide };
  saveProjects(data);

  res.json({ success: true });
});

// List every file directly inside a project folder (for the manager UI)
app.get('/api/project-files/:projectName', (req, res) => {
  const projectName  = req.params.projectName;
  const projectPath  = path.join(htmlDir, projectName);

  if (!projectPath.startsWith(htmlDir)) return res.status(403).send('Forbidden');

  fs.readdir(projectPath, (err, files) => {
    if (err) return res.status(404).send('Project not found');
    res.json(files);
  });
});

/* ──────────────────────────────────────────────────────────────── */
/* START SERVER                                                    */
/* ──────────────────────────────────────────────────────────────── */
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
