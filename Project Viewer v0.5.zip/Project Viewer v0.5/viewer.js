const selector = document.getElementById('fileList');
const viewer = document.getElementById('viewer');

async function loadProjects() {
  const res = await fetch('/list-projects');
  const projects = await res.json();
  selector.innerHTML = '';

  projects.forEach(p => {
    const option = document.createElement('option');
    option.value = p;
    option.textContent = p;
    selector.appendChild(option);
  });

  if (projects.length) {
    selector.value = projects[0];
    loadProject(projects[0]);
  }
}

selector.addEventListener('change', () => loadProject(selector.value));

function loadProject(projectPath) {
  viewer.src = `/load-html/${encodeURIComponent(projectPath)}/index.html`;
}

loadProjects();
